﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FacetedSearch3
{
    public static class OntologyElementConverter
    {
        public static HydroDesktop.CUAHSIFacetedSearch.OntologyElement Serialize()
        {
            return new HydroDesktop.CUAHSIFacetedSearch.OntologyElement();
        }
    }
}
