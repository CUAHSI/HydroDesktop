﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FacetedSearch3
{
    public class OntologyElementForDisplayComparer : IEqualityComparer<HydroDesktop.CUAHSIFacetedSearch.OntologyElement>
    {
        public bool Equals(HydroDesktop.CUAHSIFacetedSearch.OntologyElement x, HydroDesktop.CUAHSIFacetedSearch.OntologyElement y)
        {
            // return x.cVocabularyID == y.cVocabularyID;
            return x.cConceptID == y.cConceptID;
        }

        public int GetHashCode(HydroDesktop.CUAHSIFacetedSearch.OntologyElement obj)
        {
            // return obj.cVocabularyID.GetHashCode();
            return obj.cConceptID.GetHashCode();
        }
    }
}
