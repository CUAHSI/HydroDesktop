plotDataSeriesSetX <-
function( datavals, Xheader){
    plot (datavals$Xheader, datavals$DataValue  )
}

