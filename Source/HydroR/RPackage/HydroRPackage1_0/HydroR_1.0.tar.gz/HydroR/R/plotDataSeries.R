plotDataSeries <-
function(datavals){
    plot(datavals$DataValue)
}

