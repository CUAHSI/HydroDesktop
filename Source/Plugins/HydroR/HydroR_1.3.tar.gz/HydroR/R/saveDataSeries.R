saveDataSeries <-
function(connectionString, newSeries, SQLite = TRUE, overwrite= TRUE)
{
	if(SQLite==TRUE)
  {
		driver<-dbDriver("SQLite")
    con<- dbConnect(driver, dbname=connectionString)
    dbBeginTransaction(con)
		
		siteID<-getSiteID(con, newSeries$Site, overwrite)
		vunitsID<-getUnitsID(con, newSeries$VariableUnits,overwrite)
		tunitsID<-getUnitsID(con, newSeries$TimeUnits,overwrite)	
		variableID<-getVariableID(con, newSeries$Variable, overwrite)		
		methodID<-getMethodID(con, newSeries$Method, overwrite)		
		sourceID<-getSourceID(con, newSeries$Source, overwrite)		
		qclID<-getQualityControlLevelID(con, newSeries$QualityControlLevel, overwrite)
			
		SeriesID<-getSeriesID(con, list(site=siteID, variable=variableID, method=methodID, qcl=qclID, sources=sourceID), newSeries$DataSeries, newSeries$DataValues , overwrite)
		   
       
    ser<-newSeries$DataValues
		for(i in 1:length(newSeries$DataValues$DataValue))
    {		                                               			
		    if(is.null(ser$DataValue[i])|| is.null(ser$LocalDateTime[i])|| is.null(ser$UTCOffset[i])||  is.null(ser$CensorCode[i])||is.null(ser$DateTimeUTC[i])|| !nchar(ser$DataValue[i])|| !nchar(ser$LocalDateTime[i])|| !nchar(ser$UTCOffset[i])|| !nchar(ser$CensorCode[i])|| !nchar(ser$DateTimeUTC[i]))
			   {
			     dbDisconnect(con) 
				    stop(paste("All of the Mandatory Values information was not filled out for row #", i, sep= ""))                    				
			   }
        else
        {
			     if(overwrite==FALSE)
            {			
				    #print( paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",SeriesID,", ", ser$DataValue[i],", ",dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", ", dbFormat(ser$OffsetTypeID[i]),", ", dbFormat(ser$CensorCode[i]),", ", dbFormat(ser$QualifierID[i]),", ", dbFormat(ser$SampleID[i]),", ", dbFormat(ser$FileID[i]), ")", sep=""))
				    dbGetQuery(con,paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",SeriesID,", ", ser$DataValue[i],", ",dbFormat(ser$ValueAccuracy[i]),", '",ser$LocalDateTime[i],"', ",dbFormat(ser$UTCOffset[i]),", '",ser$DateTimeUTC[i],"', ", dbFormat(ser$OffsetValue[i]),", ", dbFormat(ser$OffsetTypeID[i]),", ", dbFormat(ser$CensorCode[i]),", ", dbFormat(ser$QualifierID[i]),", ", dbFormat(ser$SampleID[i]),", ", dbFormat(ser$FileID[i]), ")", sep=""))
			     }	
			     else
          {	
				    count<-dbGetQuery(con, paste("SELECT COUNT(DataValue) FROM DataValues WHERE SeriesID=",SeriesID, " AND LocalDateTime = '", newSeries$DataValues$LocalDateTime[i],"'", sep=""))			
				    if (count==0)
            {
					     #print(paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",dbFormat(SeriesID),", ", dbFormat(ser$DataValue[i]),", ",	dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", '", dbFormat(ser$OffsetTypeID[i]),"', '", dbFormat(ser$CensorCode[i]),"', '", dbFormat(ser$QualifierID[i]),"', '", dbFormat(ser$SampleID[i]),"', '", dbFormat(ser$FileID[i]), "')", sep=""))
					     dbGetQuery(con,paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",dbFormat(SeriesID),", ", dbFormat(ser$DataValue[i]),", ",	dbFormat(ser$ValueAccuracy[i]),", '", ser$LocalDateTime[i],"', ",dbFormat(ser$UTCOffset[i]),", '",ser$DateTimeUTC[i],"', ", dbFormat(ser$OffsetValue[i]),", '", dbFormat(ser$OffsetTypeID[i]),"', '", dbFormat(ser$CensorCode[i]),"', '", dbFormat(ser$QualifierID[i]),"', '", dbFormat(ser$SampleID[i]),"', '", dbFormat(ser$FileID[i]), "')", sep=""))
				    }
		        else
            {
					     #print(paste("UPDATE DataValues SET DataValue=", newSeries$DataValues$DataValue[i], " WHERE SeriesID=",SeriesID, " AND LocalDateTime ='", format(newSeries$DataValues$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"'", sep=""))		
					     dbGetQuery(con, paste("UPDATE DataValues SET DataValue=", newSeries$DataValues$DataValue[i], " WHERE SeriesID=",SeriesID, " AND LocalDateTime ='", newSeries$DataValues$LocalDateTime[i],"'", sep=""))		
		        }
			    } 
        }		
		  }			
		  dbCommit(con)	  
  	  dbDisconnect(con)		
	}    
	
	getDataSeries(connectionString, SeriesID, SQLite, startDate=min(as.character(newSeries$DataValues$LocalDateTime)), endDate=max(as.character(newSeries$DataValues$LocalDateTime)))
}
