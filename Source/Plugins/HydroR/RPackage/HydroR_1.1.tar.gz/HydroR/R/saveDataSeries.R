saveDataSeries <-
function(connectionString, newSeries, SQLite = TRUE, overwrite= TRUE){
	if(SQLite==TRUE){
		driver<-dbDriver("SQLite")
        con<- dbConnect(driver, dbname=connectionString)
        dbBeginTransaction(con)
		
		siteID<-getSiteID(con, newSeries$Site, overwrite)
		variableID<-getVariableID(con, newSeries$Variable, overwrite)		
		methodID<-getMethodID(con, newSeries$Method, overwrite)		
		sourceID<-getSourceID(con, newSeries$Sources, overwrite)		
		qclID<-getQualityControlLevelID(con, newSeries$QualityControlLevel, overwrite)
		vunitsID<-getUnitsID(con, newSeries$VariableUnits,overwrite)
		tunitsID<-getUnitsID(con, newSeries$TimeUnits,overwrite)		
		SeriesID<-getSeriesID(con, list(site=siteID, variable=variableID, method=methodID, qcl=qclID, sources=sourceID), newSeries$DataSeries, newSeries$DataValues , overwrite)
		 
		for(i in 1:length(newSeries$DataValues$DataValue)){		
			ser<-newSeries$DataValues
			if(overwrite==FALSE){			
				#print( paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",SeriesID,", ", ser$DataValue[i],", ",dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", ", dbFormat(ser$OffsetTypeID[i]),", ", dbFormat(ser$CensorCode[i]),", ", dbFormat(ser$QualifierID[i]),", ", dbFormat(ser$SampleID[i]),", ", dbFormat(ser$FileID[i]), ")", sep=""))
				dbGetQuery(con,paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",SeriesID,", ", ser$DataValue[i],", ",dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", ", dbFormat(ser$OffsetTypeID[i]),", ", dbFormat(ser$CensorCode[i]),", ", dbFormat(ser$QualifierID[i]),", ", dbFormat(ser$SampleID[i]),", ", dbFormat(ser$FileID[i]), ")", sep=""))
			}	
			else{	
				count<-dbGetQuery(con, paste("SELECT COUNT(DataValue) FROM DataValues WHERE SeriesID=",SeriesID, " AND LocalDateTime = '", format(newSeries$DataValues$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"'", sep=""))			
				if (count==0){
					#print(paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",dbFormat(SeriesID),", ", dbFormat(ser$DataValue[i]),", ",	dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", '", dbFormat(ser$OffsetTypeID[i]),"', '", dbFormat(ser$CensorCode[i]),"', '", dbFormat(ser$QualifierID[i]),"', '", dbFormat(ser$SampleID[i]),"', '", dbFormat(ser$FileID[i]), "')", sep=""))
					dbGetQuery(con,paste("INSERT INTO DataValues VALUES(",getNextValueID(con),", ",dbFormat(SeriesID),", ", dbFormat(ser$DataValue[i]),", ",	dbFormat(ser$ValueAccuracy[i]),", '", format(ser$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"', ",dbFormat(ser$UTCOffset[i]),", '",format(ser$DateTimeUTC[i],"%Y-%m-%d %H:%M:%S"),"', ", dbFormat(ser$OffsetValue[i]),", '", dbFormat(ser$OffsetTypeID[i]),"', '", dbFormat(ser$CensorCode[i]),"', '", dbFormat(ser$QualifierID[i]),"', '", dbFormat(ser$SampleID[i]),"', '", dbFormat(ser$FileID[i]), "')", sep=""))
				}
				else{
					#print(paste("UPDATE DataValues SET DataValue=", newSeries$DataValues$DataValue[i], " WHERE SeriesID=",SeriesID, " AND LocalDateTime ='", format(newSeries$DataValues$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"'", sep=""))		
					dbGetQuery(con, paste("UPDATE DataValues SET DataValue=", newSeries$DataValues$DataValue[i], " WHERE SeriesID=",SeriesID, " AND LocalDateTime ='", format(newSeries$DataValues$LocalDateTime[i],"%Y-%m-%d %H:%M:%S"),"'", sep=""))		
				}
			} 		
		}			
		dbCommit(con)	  
	    dbDisconnect(con)		
	}
	getDataSeries(connectionString, SeriesID, SQLite, startDate=format(min(newSeries$DataValues$LocalDateTime),"%Y-%m-%d %H:%M:%S"), endDate=format(max(newSeries$DataValues$LocalDateTime),"%Y-%m-%d %H:%M:%S"))
}

