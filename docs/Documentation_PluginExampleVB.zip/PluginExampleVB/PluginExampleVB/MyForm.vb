﻿Imports DotSpatial.Controls
Imports DotSpatial.Data
Imports DotSpatial.Symbology
Imports DotSpatial.Topology
Imports HydroDesktop.Configuration
Imports HydroDesktop.Database
Imports HydroDesktop.Interfaces


Public Class MyForm

    Public Property MapArgs

    Private Sub MyForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'populate the 'statistic' combo box
        cbStatistic.Items.Add("AVG")
        cbStatistic.Items.Add("MIN")
        cbStatistic.Items.Add("MAX")
        cbStatistic.Items.Add("SUM")
        cbStatistic.SelectedIndex = 0

        'set default start date to one year ago
        dpStartDate.Value = DateTime.Now.Date.AddYears(-1)

        'get the available variables
        Dim conString As String = Settings.Instance.DataRepositoryConnectionString
        Dim db As DbOperations = New DbOperations(conString, DatabaseTypes.SQLite)
        Dim sql As String = "SELECT VariableID, VariableName FROM Variables"
        Dim tab As DataTable = db.LoadTable(sql)

        '/data binding
        cbVariableName.DisplayMember = "VariableName"
        cbVariableName.ValueMember = "VariableID"
        cbVariableName.DataSource = tab

    End Sub

    Private Sub btnCreateMap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateMap.Click

        'get the selected statistic and selected variableID
        Dim statistic As String = cbStatistic.Text
        Dim variableID As Integer = Convert.ToInt32(cbVariableName.SelectedValue)
        Dim valueColumn As String = String.Format("{0}_VALUE", statistic)

        'construct the SQL string
        Dim sqlQuery As String = String.Format(
        "SELECT {0}(dv.DataValue) AS '{1}', s.Longitude, s.Latitude, " +
        "s.SiteName, s.SiteCode, ds.SeriesID " +
        "FROM DataValues dv, DataSeries ds, Sites s " +
        "WHERE dv.SeriesID = ds.SeriesID AND ds.SiteID = s.SiteID AND ds.VariableID = {2} GROUP BY ds.SeriesID",
                statistic, valueColumn, variableID)

        'connect to the database
        Dim conString As String = Settings.Instance.DataRepositoryConnectionString
        Dim db As DbOperations = New DbOperations(conString, DatabaseTypes.SQLite)

        Dim tab As DataTable = db.LoadTable(sqlQuery)

        'export the data table to a shapefile
        Dim variableName As String = cbVariableName.Text
        Dim shapeFileName As String = String.Format("{0}\{1}_{2}.shp", _
        Settings.Instance.TempDirectory, statistic, variableName)

        'call the TableToShapefile function
        TableToShapefile(tab, shapeFileName)

        'add featureSet to the map
        Dim newLayer As IMapLayer = MapArgs.Map.Layers.Add(shapeFileName)

        'add labels
        MapArgs.Map.AddLabels(newLayer, String.Format("[{0}]", valueColumn), String.Empty,New LabelSymbolizer(), valueColumn)

        'create the size categories
        CreateCategories(newLayer, valueColumn)

    End Sub

    'This function exports a table to shapefile. The data table must have
    'a 'Longitude' and 'Latitude' column.        
    Sub TableToShapefile(ByVal tab As DataTable, ByVal shapeFileName As String)

        'create a new map layer and add it to the map
        Dim fs As New FeatureSet(FeatureType.Point)
        fs.DataTable = tab.Clone()

        For Each dr As DataRow In tab.Rows
            'create a new point and add it to the featureSet
            Dim lon As Double = Convert.ToDouble(dr("Longitude"))
            Dim lat As Double = Convert.ToDouble(dr("Latitude"))
            Dim pt As New DotSpatial.Topology.Point(lon, lat)
            Dim f As IFeature = fs.AddFeature(pt)

            'for each added feature, copy the attribute values
            For i As Integer = 0 To tab.Columns.Count - 1
                f.DataRow(i) = dr(i)
            Next
        Next

        'set the projection and save to shapefile
        fs.Projection = New DotSpatial.Projections.ProjectionInfo("+proj=longlat +ellps=WGS84 +no_defs")
        fs.Reproject(MapArgs.Map.Projection)
        fs.Filename = shapeFileName
        fs.Save()
        fs.Dispose()
    End Sub


    Sub CreateCategories(ByVal layer As MapPointLayer, ByVal fieldName As String)

        'Create a new PointScheme
        Dim scheme As New PointScheme

        'Set the ClassificationType for the Scheme 
        scheme.EditorSettings.ClassificationType = ClassificationType.Quantities
        scheme.EditorSettings.IntervalMethod = IntervalMethod.Quantile
        scheme.EditorSettings.UseSizeRange = True
        scheme.EditorSettings.UseColorRange = True
        scheme.EditorSettings.StartColor = Drawing.Color.LightBlue
        scheme.EditorSettings.EndColor = Drawing.Color.DarkBlue
        scheme.EditorSettings.StartSize = 5.0
        scheme.EditorSettings.EndSize = 20.0

        'Set the UniqueValue field name
        scheme.EditorSettings.FieldName = fieldName

        'create categories based on attributes table and field name
        scheme.CreateCategories(layer.DataSet.DataTable)

        'Set the scheme to stateLayer's symbology
        layer.Symbology = scheme
    End Sub


End Class