﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MyForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dpStartDate = New System.Windows.Forms.DateTimePicker()
        Me.dpEndDate = New System.Windows.Forms.DateTimePicker()
        Me.lblStartDate = New System.Windows.Forms.Label()
        Me.lblEndDate = New System.Windows.Forms.Label()
        Me.cbVariableName = New System.Windows.Forms.ComboBox()
        Me.cbStatistic = New System.Windows.Forms.ComboBox()
        Me.lblVariable = New System.Windows.Forms.Label()
        Me.lblStatistic = New System.Windows.Forms.Label()
        Me.btnCreateMap = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'dpStartDate
        '
        Me.dpStartDate.Location = New System.Drawing.Point(24, 28)
        Me.dpStartDate.Name = "dpStartDate"
        Me.dpStartDate.Size = New System.Drawing.Size(200, 20)
        Me.dpStartDate.TabIndex = 0
        '
        'dpEndDate
        '
        Me.dpEndDate.Location = New System.Drawing.Point(24, 80)
        Me.dpEndDate.Name = "dpEndDate"
        Me.dpEndDate.Size = New System.Drawing.Size(200, 20)
        Me.dpEndDate.TabIndex = 1
        '
        'lblStartDate
        '
        Me.lblStartDate.AutoSize = True
        Me.lblStartDate.Location = New System.Drawing.Point(24, 9)
        Me.lblStartDate.Name = "lblStartDate"
        Me.lblStartDate.Size = New System.Drawing.Size(55, 13)
        Me.lblStartDate.TabIndex = 2
        Me.lblStartDate.Text = "Start Date"
        '
        'lblEndDate
        '
        Me.lblEndDate.AutoSize = True
        Me.lblEndDate.Location = New System.Drawing.Point(27, 61)
        Me.lblEndDate.Name = "lblEndDate"
        Me.lblEndDate.Size = New System.Drawing.Size(52, 13)
        Me.lblEndDate.TabIndex = 3
        Me.lblEndDate.Text = "End Date"
        '
        'cbVariableName
        '
        Me.cbVariableName.FormattingEnabled = True
        Me.cbVariableName.Location = New System.Drawing.Point(247, 28)
        Me.cbVariableName.Name = "cbVariableName"
        Me.cbVariableName.Size = New System.Drawing.Size(121, 21)
        Me.cbVariableName.TabIndex = 4
        '
        'cbStatistic
        '
        Me.cbStatistic.FormattingEnabled = True
        Me.cbStatistic.Location = New System.Drawing.Point(247, 80)
        Me.cbStatistic.Name = "cbStatistic"
        Me.cbStatistic.Size = New System.Drawing.Size(121, 21)
        Me.cbStatistic.TabIndex = 5
        '
        'lblVariable
        '
        Me.lblVariable.AutoSize = True
        Me.lblVariable.Location = New System.Drawing.Point(247, 9)
        Me.lblVariable.Name = "lblVariable"
        Me.lblVariable.Size = New System.Drawing.Size(45, 13)
        Me.lblVariable.TabIndex = 6
        Me.lblVariable.Text = "Variable"
        '
        'lblStatistic
        '
        Me.lblStatistic.AutoSize = True
        Me.lblStatistic.Location = New System.Drawing.Point(247, 60)
        Me.lblStatistic.Name = "lblStatistic"
        Me.lblStatistic.Size = New System.Drawing.Size(44, 13)
        Me.lblStatistic.TabIndex = 7
        Me.lblStatistic.Text = "Statistic"
        '
        'btnCreateMap
        '
        Me.btnCreateMap.Location = New System.Drawing.Point(293, 127)
        Me.btnCreateMap.Name = "btnCreateMap"
        Me.btnCreateMap.Size = New System.Drawing.Size(75, 23)
        Me.btnCreateMap.TabIndex = 8
        Me.btnCreateMap.Text = "Create Map!"
        Me.btnCreateMap.UseVisualStyleBackColor = True
        '
        'MyForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 162)
        Me.Controls.Add(Me.btnCreateMap)
        Me.Controls.Add(Me.lblStatistic)
        Me.Controls.Add(Me.lblVariable)
        Me.Controls.Add(Me.cbStatistic)
        Me.Controls.Add(Me.cbVariableName)
        Me.Controls.Add(Me.lblEndDate)
        Me.Controls.Add(Me.lblStartDate)
        Me.Controls.Add(Me.dpEndDate)
        Me.Controls.Add(Me.dpStartDate)
        Me.Name = "MyForm"
        Me.Text = "Quick Map"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dpStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents dpEndDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblStartDate As System.Windows.Forms.Label
    Friend WithEvents lblEndDate As System.Windows.Forms.Label
    Friend WithEvents cbVariableName As System.Windows.Forms.ComboBox
    Friend WithEvents cbStatistic As System.Windows.Forms.ComboBox
    Friend WithEvents lblVariable As System.Windows.Forms.Label
    Friend WithEvents lblStatistic As System.Windows.Forms.Label
    Friend WithEvents btnCreateMap As System.Windows.Forms.Button
End Class
