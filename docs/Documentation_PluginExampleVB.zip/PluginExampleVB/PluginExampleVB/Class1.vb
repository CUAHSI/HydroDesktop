﻿Imports DotSpatial.Controls
Imports DotSpatial.Controls.RibbonControls

<Plugin("Plugin Example VB")>
Public Class Class1
    Inherits Extension
    Implements IMapPlugin

    Private _myPanel As RibbonPanel
    Private _myButton As RibbonButton
    Private _mapArgs As IMapPluginArgs


    Public Overloads Sub Activate() Implements DotSpatial.Controls.IExtension.Activate
        MyBase.OnActivate()
    End Sub

    Public Overloads Sub Deactivate() Implements DotSpatial.Controls.IExtension.Deactivate
        'remove the ribbon panel and buttons
        _mapArgs.Ribbon.Tabs(0).Panels.Remove(_myPanel)
    End Sub

    Public Overloads Property IsEnabled As Boolean Implements DotSpatial.Controls.IExtension.IsEnabled
        Get
            Return MyBase.IsEnabled
        End Get
        Set(ByVal value As Boolean)
            MyBase.IsEnabled = True
        End Set
    End Property

    Public Sub Initialize(ByVal args As DotSpatial.Controls.IMapPluginArgs) Implements DotSpatial.Controls.IMapPlugin.Initialize
        'the _mapArgs variable is used for accessing the main app
        _mapArgs = args

        'create a new ribbon panel and add it to the main ribbon
        _myPanel = New RibbonPanel("Example Plugin")
        _myButton = New RibbonButton("QuickMap")
        _myButton.Image = My.Resources.mapView
        _myButton.SmallImage = My.Resources.mapView_16x16
        _myPanel.Items.Add(_myButton)
        args.Ribbon.Tabs(0).Panels.Add(_myPanel)

        'create the button click event handler
        AddHandler _myButton.Click, AddressOf myButton_Click
    End Sub

    Sub myButton_Click()
        Dim frm As New MyForm
        'pass information about the map to the form
        frm.MapArgs = _mapArgs
        frm.Show()
    End Sub
End Class
