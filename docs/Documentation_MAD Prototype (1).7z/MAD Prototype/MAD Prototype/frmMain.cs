﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RDotNet;
using System.Diagnostics;

namespace MAD_Prototype
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            // Debug.Print "test";
            listBox1.Items.Add("test");
            //set the folder in which R.dll is located
            REngine.SetDllDirectory(@"C:\Program Files\R\R-2.13.1\bin\i386");
            
            using (REngine engine = REngine.CreateInstance("RDotNet", new[] { "-q" })) //quiet mode
            {
                // .NET Framework array to R vector.
                NumericVector group1 = engine.CreateNumericVector(new double[] { 30.02, 29.99, 30.11, 29.97, 30.01, 29.99 });
                engine.SetSymbol("group1", group1);

                //Direct parsing from R script.
                NumericVector group2 = engine.EagerEvaluate("group2 <- c(29.89, 29.93, 29.72, 29.98, 30.02, 29.98)").AsNumeric();
                       

                //Test difference of mean and get the P-value.
                GenericVector testResult = engine.EagerEvaluate("t.test(group1,group2)").AsList();
                double p = testResult["p.value"].AsNumeric().First();

                        
                listBox1.Items.Add(string.Format("Group1: [{0}]", string.Join(", ", group1)));
                listBox1.Items.Add(string.Format("Group2: [{0}]", string.Join(", ", group2)));
                listBox1.Items.Add(string.Format("P-value = {0:0.000}", p));

            }

        }

        private void btnTest2_Click(object sender, EventArgs e)
        {
            // Debug.Print "test";
            listBox1.Items.Add("test");
            //set the folder in which R.dll is located
            REngine.SetDllDirectory(@"C:\Program Files\R\R-2.13.1\bin\i386");

            using (REngine engine = REngine.CreateInstance("RDotNet", new[] { "" })) //quiet mode
            {
               //read and process an R script

                engine.EagerEvaluate("library(mvtnorm)");
                engine.EagerEvaluate("library(mvtnorm)");
                engine.EagerEvaluate("library(MASS)");
                engine.EagerEvaluate("library(RandomFields)");
                engine.EagerEvaluate("library(geoR)");
                engine.EagerEvaluate("library(fields)");
                engine.EagerEvaluate("x=seq(0,100,by=2)");
                engine.EagerEvaluate("plot(rep(x[1],length(x)),x,xlim=c(0,100),'l',xlab='Easting (m)',ylab='Northing (m)',main='Flow Domain & Corrected Measurements')");
                engine.EagerEvaluate("plot(rep(x[1],length(x)),x,xlim=c(0,100),'l',xlab='Easting (m)',ylab='Northing (m)',main='Flow Domain & Corrected Measurements')");
                engine.EagerEvaluate("for (i in 1:length(x)){");
                engine.EagerEvaluate("abline(v=x[i])");
                engine.EagerEvaluate("abline(h=x[i])}");

                engine.EagerEvaluate("xmeas=floor(runif(10,0,100))");
                engine.EagerEvaluate("ymeas=floor(runif(10,0,100))");

                engine.EagerEvaluate("for (j in 1:10){");
                engine.EagerEvaluate("ycon=sum(ymeas[j]==x)");
                engine.EagerEvaluate("xcon=sum(xmeas[j]==x)");
                engine.EagerEvaluate("if((xcon+ycon)==2){");
                engine.EagerEvaluate("xmeas[j]=xmeas[j]+1");
                engine.EagerEvaluate("ymeas[j]=ymeas[j]+1}");
                engine.EagerEvaluate("if(xcon==1&&ycon==0){");
                engine.EagerEvaluate("xmeas[j]=xmeas[j]+1}");
                engine.EagerEvaluate("if(ycon==1&&xcon==0){");
                engine.EagerEvaluate("ymeas[j]=ymeas[j]+1}");
                engine.EagerEvaluate("}");

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
    }
}
