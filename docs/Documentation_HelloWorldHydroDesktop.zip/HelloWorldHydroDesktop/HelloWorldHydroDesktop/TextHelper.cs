﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotSpatial.Data;
using System.Windows.Forms;
using System.Data;
using System.IO;
using DotSpatial.Topology;

namespace HelloWorldHydroDesktop
{
    public class TextHelper
    {
        
        public static FeatureSet OpenExcelFile()
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "txt Files|*.txt";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                DataTable excelTable = ConvertTextFileToDataTable(openDialog.FileName);
                return ConvertDataTableToFeatureSet(excelTable);
            }
            return null;
        }
        private static DataTable ConvertTextFileToDataTable(string excelFileName)
        {
            string[] txt = File.ReadAllLines(excelFileName);

            DataTable table = new DataTable();
            table.Columns.Add("lat", typeof(double));
            table.Columns.Add("long", typeof(double));
            table.Columns.Add("name", typeof(string));

            for (int i = 1; i < txt.Length; i++)
            {
                double lat= Convert.ToDouble(txt[i].Split(' ')[0]);
                double lng= Convert.ToDouble(txt[i].Split(' ')[1]);
                string name= Convert.ToString(txt[i].Split(' ')[2]);
                table.Rows.Add(lat, lng, name);
            }

            return table;

        }
        private static FeatureSet ConvertDataTableToFeatureSet(DataTable txtTable)
        {
            // See if table has the lat, long columns
            if (txtTable.Columns.Contains("lat") & txtTable.Columns.Contains("long"))
            {
                FeatureSet fs = new FeatureSet(FeatureType.Point);
                DotSpatial.Projections.GeographicCategories.World p = new DotSpatial.Projections.GeographicCategories.World();
                fs.DataTable.Columns.Add("Name");
                fs.Projection = p.WGS1984;
                //; KnownCoordinateSystems.Geographic.World.WGS1984; 
                int i=0;
                foreach (DataRow txtRow in txtTable.Rows)
                {
                    double lat = Double.Parse(txtRow["lat"].ToString());
                    double lon = Double.Parse(txtRow["long"].ToString());

                    // Add the point to the FeatureSet
                    Coordinate coord = new Coordinate(lon, lat);
                    Point point = new Point(coord);
                    IFeature feature = fs.AddFeature(point);

                        feature.DataRow["Name"] = txtRow[2];
                        i++;

                }
                return fs;
            }
            else
            {
                MessageBox.Show("The txt table must have lat and long columns.");
                return null;
            }
        }


    }
    }

