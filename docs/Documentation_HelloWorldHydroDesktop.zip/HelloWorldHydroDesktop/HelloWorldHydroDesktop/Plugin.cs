﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotSpatial.Controls;
using DotSpatial.Controls.Header;

namespace HelloWorldHydroDesktop
{
    public class PluginHelloWorld:Extension
    {
        public override void Activate()
        {
            App.HeaderControl.Add(new SimpleActionItem("Add Layer from text file", ButtonClick));
            base.Activate();
        }

        public override void Deactivate()
        {
            App.HeaderControl.RemoveAll();
            base.Deactivate();
        }

        public void ButtonClick(object sender, EventArgs e)
        {
            var featureSet = TextHelper.OpenExcelFile();

            if (featureSet != null)
            {
                //add feature set to map
                var layer = App.Map.Layers.Add(featureSet);
                layer.LegendText = "Points From Text file";
            }

        }
    }
}
