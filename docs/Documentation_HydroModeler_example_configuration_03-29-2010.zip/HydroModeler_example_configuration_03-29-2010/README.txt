This directory includes a sample model for the HydroModeler plugin to HydroDesktop.  

Notes:
1. This demo has been tested against HydroDesktop version 0.7.3736.27376.
2. This demo assumes you extracted files to C:\temp so that this readme.txt file is
   located at the directory C:\TEMP\HydroModeler_example_configuration_03-29-2010\readme.txt.
   If you are working in a different directory, you will need to edit directory paths for  
   the *.omi files included with the demo. 


Steps:

1. Start HydroDesktop 

2. Change the database (File --> Change Database) to C:\TEMP\HydroModeler_example_configuration_03-29-2010\data \cuahsi-his\DataRepository.sqlite 

3. Add the HydroModeler extension (Extensions --> Plug-ins --> HydroModler).

4. Select HydroModeler --> Open Composition and open the SmithBranchModel.opr file from
   C:\TEMP\HydroModeler_example_configuration_03-29-2010 folder.

5. Select HydroModeler --> Run. Then press the "Run!!!" button. The final event listed 
   in the Simulation progress window should have the description "Simulation finished 
    successfully ....".  

6. Close the Simulation progress window and choose "Yes" to reload the project.

7. To view the model output, select the Graph View tab --> choose Simple Filter  --> the Smith Branch theme --> 
   and then select a model node (for example, Smith Branch12).  The x-axis of the graph is controlled using the Date Range feature   located at the bottom right corner of graph.

Please send any questions, bugs, etc. to Jon Goodall (goodall@cec.sc.edu)  

---
March, 2010

