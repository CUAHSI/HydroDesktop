﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotSpatial.Controls;
using DotSpatial.Controls.Header;
using System.Windows.Forms;

namespace HelloHydroDesktop
{
    public class HelloPlugin : Extension
    {
        #region Fields

        private SimpleActionItem test1;


        private readonly string _exampleKey = "_helloWorldKey";

        #endregion

        #region Plugin operations

        public override void Activate()
        {
            AddExampleRibbon();
            base.Activate();
        }

        public override void Deactivate()
        {
            App.HeaderControl.RemoveAll();
            base.Deactivate();
        }

        #endregion

        private void AddExampleRibbon()
        {
            var head = App.HeaderControl;
            head.Add(new RootItem(_exampleKey, "ExampleRibbon") { SortOrder = 520 });

            test1 = new SimpleActionItem(_exampleKey, "", test_Click) { LargeImage = Properties.Resources.CuahsiLogo38, GroupCaption = "Hello World", Visible = true };
            head.Add(test1);
        }


        void test_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello World");
        }
    }
}
