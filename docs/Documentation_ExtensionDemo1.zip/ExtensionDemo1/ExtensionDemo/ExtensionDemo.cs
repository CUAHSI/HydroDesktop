﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotSpatial.Controls;
using DotSpatial.Controls.Header;
using DotSpatial.Topology;
using DotSpatial.Data;
using DotSpatial.Projections;
using DotSpatial.Symbology;
using System.Data;

namespace ExtensionDemo
{
    public class MyExtension: Extension
    {
        TextEntryActionItem textBox1;
        TextEntryActionItem textBox2;
        
        public override void Activate() {

            textBox1 = new TextEntryActionItem { Caption = "Latitude  :", RootKey = HeaderControl.HomeRootItemKey };

            textBox2 = new TextEntryActionItem { Caption = "Longitude:", RootKey = HeaderControl.HomeRootItemKey };

            var buttonGo = new SimpleActionItem(HeaderControl.HomeRootItemKey, "Go", buttonGo_Click);

            App.HeaderControl.Add(textBox1);
            App.HeaderControl.Add(textBox2);
            App.HeaderControl.Add(buttonGo);
            
            base.Activate();
        }       

        public override void Deactivate() {
            App.HeaderControl.RemoveAll();
            base.Deactivate();
        }

        
        void buttonGo_Click(object sender, EventArgs e) {
            //add your code here
            double lat = Double.Parse(textBox1.Text);
            double lon = Double.Parse(textBox2.Text);

            //create a point layer
            FeatureSet myFeatureSet = new FeatureSet(FeatureType.Point);
            Point myPoint = new Point(lon, lat);
            Feature myFeature = new Feature(myPoint);
            myFeatureSet.AddFeature(myPoint);
            
            //re-project the point
            myFeatureSet.Projection = KnownCoordinateSystems.Geographic.World.WGS1984;
            myFeatureSet.Reproject(App.Map.Projection);
            
            //set the point symbol
            var myLayer = App.Map.Layers.Add(myFeatureSet);
            myLayer.LegendText = "My Point";
            myLayer.Symbolizer = new PointSymbolizer(System.Drawing.Color.Red, DotSpatial.Symbology.PointShape.Ellipse, 15.0);

            //zoom to the point           
            myFeatureSet.Extent.ExpandBy(10000.0);
            App.Map.ViewExtents = myFeatureSet.Extent;
        }
    }
}
