﻿namespace PluginExampleCSharp
{
    partial class MyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dpEndDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblVariableName = new System.Windows.Forms.Label();
            this.cbVariableName = new System.Windows.Forms.ComboBox();
            this.lblStatistic = new System.Windows.Forms.Label();
            this.cbStatistic = new System.Windows.Forms.ComboBox();
            this.btnCreateMap = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dpStartDate
            // 
            this.dpStartDate.Location = new System.Drawing.Point(12, 32);
            this.dpStartDate.Name = "dpStartDate";
            this.dpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dpStartDate.TabIndex = 0;
            // 
            // dpEndDate
            // 
            this.dpEndDate.Location = new System.Drawing.Point(13, 86);
            this.dpEndDate.Name = "dpEndDate";
            this.dpEndDate.Size = new System.Drawing.Size(200, 20);
            this.dpEndDate.TabIndex = 1;
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(13, 13);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(55, 13);
            this.lblStartDate.TabIndex = 2;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(13, 69);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(52, 13);
            this.lblEndDate.TabIndex = 3;
            this.lblEndDate.Text = "End Date";
            // 
            // lblVariableName
            // 
            this.lblVariableName.AutoSize = true;
            this.lblVariableName.Location = new System.Drawing.Point(244, 13);
            this.lblVariableName.Name = "lblVariableName";
            this.lblVariableName.Size = new System.Drawing.Size(76, 13);
            this.lblVariableName.TabIndex = 4;
            this.lblVariableName.Text = "Variable Name";
            // 
            // cbVariableName
            // 
            this.cbVariableName.FormattingEnabled = true;
            this.cbVariableName.Location = new System.Drawing.Point(238, 32);
            this.cbVariableName.Name = "cbVariableName";
            this.cbVariableName.Size = new System.Drawing.Size(126, 21);
            this.cbVariableName.TabIndex = 5;
            // 
            // lblStatistic
            // 
            this.lblStatistic.AutoSize = true;
            this.lblStatistic.Location = new System.Drawing.Point(244, 69);
            this.lblStatistic.Name = "lblStatistic";
            this.lblStatistic.Size = new System.Drawing.Size(47, 13);
            this.lblStatistic.TabIndex = 6;
            this.lblStatistic.Text = "Statistic:";
            // 
            // cbStatistic
            // 
            this.cbStatistic.FormattingEnabled = true;
            this.cbStatistic.Location = new System.Drawing.Point(238, 86);
            this.cbStatistic.Name = "cbStatistic";
            this.cbStatistic.Size = new System.Drawing.Size(126, 21);
            this.cbStatistic.TabIndex = 7;
            // 
            // btnCreateMap
            // 
            this.btnCreateMap.Location = new System.Drawing.Point(289, 129);
            this.btnCreateMap.Name = "btnCreateMap";
            this.btnCreateMap.Size = new System.Drawing.Size(75, 23);
            this.btnCreateMap.TabIndex = 8;
            this.btnCreateMap.Text = "Create Map!";
            this.btnCreateMap.UseVisualStyleBackColor = true;
            this.btnCreateMap.Click += new System.EventHandler(this.btnCreateMap_Click);
            // 
            // MyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 164);
            this.Controls.Add(this.btnCreateMap);
            this.Controls.Add(this.cbStatistic);
            this.Controls.Add(this.lblStatistic);
            this.Controls.Add(this.cbVariableName);
            this.Controls.Add(this.lblVariableName);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.dpEndDate);
            this.Controls.Add(this.dpStartDate);
            this.Name = "MyForm";
            this.Text = "Quick Map";
            this.Load += new System.EventHandler(this.MyForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dpStartDate;
        private System.Windows.Forms.DateTimePicker dpEndDate;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblVariableName;
        private System.Windows.Forms.ComboBox cbVariableName;
        private System.Windows.Forms.Label lblStatistic;
        private System.Windows.Forms.ComboBox cbStatistic;
        private System.Windows.Forms.Button btnCreateMap;
    }
}