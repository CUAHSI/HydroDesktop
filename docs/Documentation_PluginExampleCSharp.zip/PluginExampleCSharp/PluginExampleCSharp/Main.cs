﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotSpatial.Controls;
using DotSpatial.Controls.RibbonControls;

namespace PluginExampleCSharp
{
    //the Main class implements the IMapPlugin interface. It also inherits from Extension.
    [Plugin("Example Plugin")]
    public class Main : Extension, IMapPlugin
    {
        private RibbonPanel _myPanel;
        private RibbonButton _myButton;
        private IMapPluginArgs _mapArgs;
        
        #region IMapPlugin Members

        public void Initialize(IMapPluginArgs args)
        {
            //the _mapArgs variable is used for accessing the main app
            _mapArgs = args;
            
            //create a new ribbon panel and add it to the
            //main ribbon
            _myPanel = new RibbonPanel("Example Plugin");
            _myButton = new RibbonButton("QuickMap");
            _myButton.Image = Properties.Resources.mapView;
            _myButton.SmallImage = Properties.Resources.mapView_16x16;
            _myPanel.Items.Add(_myButton);
            args.Ribbon.Tabs[0].Panels.Add(_myPanel);

            //handle the click event
            _myButton.Click += new EventHandler(_myButton_Click);
        }

        //the button click event
        void _myButton_Click(object sender, EventArgs e)
        {
            MyForm frm = new MyForm();
            frm.MapArgs = _mapArgs;
            frm.Show();
        }

        #endregion

        protected override void OnDeactivate()
        {
            //remove the ribbon panel and all its items
            _mapArgs.Ribbon.Tabs[0].Panels.Remove(_myPanel);
            
            base.OnDeactivate();
        }
    }
}
