﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DotSpatial.Controls;
using DotSpatial.Data;
using DotSpatial.Topology;
using HydroDesktop.Configuration;
using HydroDesktop.Database;
using HydroDesktop.Interfaces;
using DotSpatial.Projections;
using DotSpatial.Symbology;

namespace PluginExampleCSharp
{
    public partial class MyForm : Form
    {
        public MyForm()
        {
            InitializeComponent();
        }

        //this property references the main application and main map
        public IMapPluginArgs MapArgs { get; set; }

        //initializes the combo boxes
        private void MyForm_Load(object sender, EventArgs e)
        {
            //populate the 'statistic' combo box
            cbStatistic.Items.Add("AVG");
            cbStatistic.Items.Add("MIN");
            cbStatistic.Items.Add("MAX");
            cbStatistic.Items.Add("SUM");
            cbStatistic.SelectedIndex = 0;

            //set default start date to one year ago
            dpStartDate.Value = DateTime.Now.Date.AddYears(-1);

            //get the available variables
            string conString = Settings.Instance.DataRepositoryConnectionString;
            DbOperations db = new DbOperations(conString, DatabaseTypes.SQLite);
            string sql = "SELECT VariableID, VariableName FROM Variables";
            DataTable tab = db.LoadTable(sql);

            //data binding
            cbVariableName.DisplayMember = "VariableName";
            cbVariableName.ValueMember = "VariableID";
            cbVariableName.DataSource = tab;
            
        }

        private void btnCreateMap_Click(object sender, EventArgs e)
        {
            //get the selected statistic and selected variableID
            string statistic = cbStatistic.Text;
            int variableID = Convert.ToInt32(cbVariableName.SelectedValue);
            string valueColumn = String.Format("{0}_VALUE", statistic);

            //form the SQL string
            string sqlQuery = String.Format(
                "SELECT {0}(dv.DataValue) AS '{1}', s.Longitude, s.Latitude, s.SiteName, s.SiteCode, ds.SeriesID " +
                "FROM DataValues dv, DataSeries ds, Sites s " +
                "WHERE dv.SeriesID = ds.SeriesID AND ds.SiteID = s.SiteID AND ds.VariableID = {2} GROUP BY ds.SeriesID",
                statistic, valueColumn, variableID);
            
            //connect to the database
            string conString = Settings.Instance.DataRepositoryConnectionString;
            DbOperations db = new DbOperations(conString, DatabaseTypes.SQLite);

            DataTable tab = db.LoadTable(sqlQuery);

            //export the data table to a shapefile
            string variableName = cbVariableName.Text;
            string shapeFileName = String.Format(@"{0}\{1}_{2}.shp", Settings.Instance.TempDirectory, statistic, variableName);
            TableToShapefile(tab, shapeFileName);

            //add featureSet to the map
            MapPointLayer newLayer = MapArgs.Map.Layers.Add(shapeFileName) as MapPointLayer;

            //add labels
            MapArgs.Map.AddLabels((IFeatureLayer)newLayer, String.Format("[{0}]", valueColumn), String.Empty,
                new LabelSymbolizer(), valueColumn);

            //change map symbology
            CreateCategories(newLayer, valueColumn);

        }

        //This methods exports a DataTable to a shapefile. The data table must have
        //a 'Longitude' and 'Latitude' column. The shapefile has all attributes of the original table.
        private void TableToShapefile(DataTable tab, string shapeFileName)
        {
            //create a new map layer and add it to the map
            FeatureSet fs = new FeatureSet(FeatureType.Point);
            fs.DataTable = tab.Clone();
            foreach (DataRow dr in tab.Rows)
            {
                //create a new point and add it to the featureSet
                double lon = Convert.ToDouble(dr["Longitude"]);
                double lat = Convert.ToDouble(dr["Latitude"]);
                DotSpatial.Topology.Point pt = new DotSpatial.Topology.Point(lon, lat);
                IFeature f = fs.AddFeature(pt);

                //for each added feature, copy the attribute values
                for (int i = 0; i < tab.Columns.Count; i++)
                {
                    f.DataRow[i] = dr[i];
                }
            }

            //set the projection
            fs.Projection = new ProjectionInfo("+proj=longlat +ellps=WGS84 +no_defs");
            fs.Reproject(MapArgs.Map.Projection);
            
            fs.Filename = shapeFileName;
            fs.Save();
            fs.Dispose();
        }

        private void CreateCategories(MapPointLayer layer, string fieldName)
        {
            //Create a new PointScheme
            PointScheme scheme = new PointScheme();

            //Set the ClassificationType for the Scheme via EditorSettings
            scheme.EditorSettings.ClassificationType = ClassificationType.Quantities;
            scheme.EditorSettings.IntervalMethod = IntervalMethod.Quantile;
            scheme.EditorSettings.UseSizeRange = true;
            scheme.EditorSettings.UseColorRange = true;
            scheme.EditorSettings.StartColor = Color.LightBlue;
            scheme.EditorSettings.EndColor = Color.DarkBlue;
            scheme.EditorSettings.StartSize = 5.0;
            scheme.EditorSettings.EndSize = 20.0;

            //Set the UniqueValue field name
            //Here STATE_NAME would be the Unique value field
            scheme.EditorSettings.FieldName = fieldName;

            //create categories on the scheme based on the attributes table and field name
            //In this case field name is STATE_NAME
            scheme.CreateCategories(layer.DataSet.DataTable);

            //Set the scheme to stateLayer's symbology
            layer.Symbology = scheme;

        }
    }
}
