This directory includes a sample model for the HydroModeler plugin to HydroDesktop.  To configure, please complete the following steps.

1. Move the DataRepository.sqlite database currently in the same directory as this readme.txt file to the C:\Program Files\HydroDesktop\databases directory. Note: You may want to rename the existing DataRepository.sqlite file in the HydroDesktop installation directory in case you want to revert back to it at a later point.

2. Start HdyroDesktop and add the HydroModeler extension (Extensions --> Plug-ins --> HydroModler).

3. Choose HydroModeler --> Open Configuration. Browse to and open the SmithBranchModel.opr file, which is in the same directory as this readme.txt file

4. Select HydroModeler --> Run. The presss the "Run!!!" button. The final event listed in the Simulation progress window should have the description "Simulation finished successfully ....".  Close the Simulation progress window and choose "Yes" to reload the project.

5. To view the model output, select the Graph View tab --> the Smith Branch theme --> and then select a model node (for example, Smith Branch12).  

Please send any questions, bugs, etc. to Jon Goodall (goodall@cec.sc.edu) or Tony Castronova (castrona@cec.sc.edu). 

---
December, 2009

