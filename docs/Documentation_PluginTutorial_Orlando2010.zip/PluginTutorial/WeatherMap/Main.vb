﻿Imports System.Windows.Forms
Imports MapWindow.Components
Imports MapWindow.Map
Imports MapWindow.Plugins

<MapWindowPlugin("Weather Map", Author:="HydroDesktop Workshop", UniqueName:="WeatherMap_1_0", Version:="1.0")> _
Public Class Main
    Inherits Extension
    Implements IMapPlugin

    'declare a class variable with a reference to the main Map
    Private _mapWin As IMapPluginArgs

    'Initialize the plugin and get the map handle
    Public Sub Initialize(ByVal args As IMapPluginArgs) Implements IMapPlugin.Initialize

        'Assign the map handle
        _mapWin = args

        'To add the first menu item
        Dim menu1 As New ToolStripMenuItem("Weather Map")
        menu1.Name = "mnuWeatherMap"

        'To add the second menu item
        Dim menu2 As New ToolStripMenuItem("Create Map")
        menu1.DropDownItems.Add(menu2)

        'Add the click event handler
        AddHandler menu2.Click, AddressOf Menu1_click
        _mapWin.MainMenu.Items.Add(menu1)

    End Sub

    'This code runs when the menu item is clicked
    Private Sub Menu1_click()
        'MsgBox("You clicked the 'Create Map' menu item")
        Dim frm As New WeatherMapForm
        frm.Show()
    End Sub

    'Dectivate method - occurs when the plugin is unchecked in the plugin menu
    Public Overloads Sub Deactivate() Implements IMapPlugin.Deactivate
        MyBase.Deactivate()
        'To remove the menu item
        _mapWin.MainMenu.Items.RemoveByKey("mnuWeatherMap")
    End Sub

    'Activate method - just use the base class implementation
    Public Overloads Sub Activate() Implements IMapPlugin.Activate
        MyBase.Activate()
    End Sub

    'IsEnabled property - just use the base class implementation
    Public Overloads Property IsEnabled() As Boolean Implements IMapPlugin.IsEnabled
        Get
            Return MyBase.IsEnabled
        End Get

        Set(ByVal value As Boolean)
            MyBase.IsEnabled = value
        End Set
    End Property

End Class
