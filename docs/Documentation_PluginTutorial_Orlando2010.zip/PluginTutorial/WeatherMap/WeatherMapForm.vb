﻿Imports System.Data.Common
Imports MapWindow.Data
Imports MapWindow.Map
Imports MapWindow.Geometries
Imports MapWindow.Drawing
Imports HydroDesktop.Database
Imports System.Drawing


Public Class WeatherMapForm

    Private selectedThemeID As Integer = 0

    Private db As DbOperations

    Private siteLayer As MapPointLayer

    Private Sub WeatherMapForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Set the db manager
        db = Config.DefaultDataRepositoryOperations

        'Get the table of variables
        Dim sqlQuery As String = "SELECT VariableID, VariableName FROM Variables"
        Dim tblVariables As DataTable = db.LoadTable("tblVariables", sqlQuery)
        ComboBox1.DataSource = tblVariables
        ComboBox1.DisplayMember = "VariableName"
        ComboBox1.ValueMember = "VariableID"

        'Add the 'STATES' Layer
        Dim statesFileName As String = AppDomain.CurrentDomain.BaseDirectory & "\Maps\BaseData\states.shp"

        Dim statesLayer As MapPolygonLayer = Map1.Layers.Add(statesFileName)
        statesLayer.Symbolizer.SetFillColor(Color.Transparent)

    End Sub

    Private Sub btnCreateMap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateMap.Click

        'Get the selected variable id
        Dim selectedVariableID As Integer = Me.ComboBox1.SelectedValue

        'Get the start time and end time
        Dim startTime As DateTime = DateTimePicker1.Value
        Dim endTime As DateTime = DateTimePicker1.Value.AddDays(1)

        'Create the SQL query with VariableID, StartTime and EndTime parameters
        Dim sqlQuery As String = _
        "select SiteName, Latitude, Longitude, " & _
        "MAX(datavalue) AS 'max', MIN(datavalue) AS 'min' from sites " & _
        "INNER JOIN DataSeries ON Sites.SiteID = DataSeries.SiteID " & _
        "INNER JOIN Variables ON DataSeries.VariableID = Variables.VariableID " & _
        "INNER JOIN DataValues ON DataSeries.SeriesID = DataValues.SeriesID " & _
        "WHERE Variables.VariableID = ? AND LocalDateTime > ? AND LocalDateTime < ? " & _
        "GROUP BY SiteName, Latitude, Longitude"

        'Setup the database select command
        Dim cmd As DbCommand = db.CreateCommand(sqlQuery)
        cmd.Parameters.Add(db.CreateParameter(DbType.Int32, selectedVariableID))
        cmd.Parameters.Add(db.CreateParameter(DbType.DateTime, startTime))
        cmd.Parameters.Add(db.CreateParameter(DbType.DateTime, endTime))

        'Display the table
        Dim table As DataTable = db.LoadTable("table1", cmd)
        DataGridView1.DataSource = table

        'Refresh the Map
        CreateMap(table)

    End Sub

    'To create the customized map
    Sub CreateMap(ByVal sourceTable As DataTable)

        'remove any existing layers
        Map1.Layers.Clear()

        'Add the 'STATES' Layer
        Dim statesFileName As String = AppDomain.CurrentDomain.BaseDirectory & "\Maps\BaseData\states.shp"
        Dim statesLayer As MapPolygonLayer = Map1.Layers.Add(statesFileName)
        statesLayer.Symbolizer.SetFillColor(Color.Transparent)


        Dim fs As New FeatureSet(MapWindow.Geometries.FeatureTypes.Point)

        'add columns to the data table
        fs.DataTable.Columns.Add(New DataColumn("SiteName", GetType(String)))
        fs.DataTable.Columns.Add(New DataColumn("Maximum", GetType(Double)))
        fs.DataTable.Columns.Add(New DataColumn("Minimum", GetType(Double)))

        For Each row As DataRow In sourceTable.Rows
            Dim latitude As Double = CDbl(row.Item("Latitude"))
            Dim longitude As Double = CDbl(row.Item("Longitude"))
            Dim coordinate As New Coordinate(longitude, latitude)
            Dim newFeature As Feature = New Feature(coordinate)
            fs.Features.Add(newFeature)

            'Assign the attributes
            newFeature.DataRow.Item("SiteName") = row.Item("SiteName")
            newFeature.DataRow.Item("Maximum") = row.Item("Max")
            newFeature.DataRow.Item("Minimum") = row.Item("Min")
        Next

        DataGridView1.DataSource = fs.DataTable

        'Add the feature set to the map as a new layer
        Dim myLayer As New MapPointLayer(fs)

        Dim myScheme As New MapWindow.Drawing.PointScheme
        myScheme.EditorSettings.ClassificationType = MapWindow.Drawing.ClassificationTypes.Quantities
        myScheme.EditorSettings.NumBreaks = 10
        myScheme.EditorSettings.UseColorRange = True
        myScheme.EditorSettings.IntervalMethod = MapWindow.Drawing.IntervalMethods.Quantile
        myScheme.EditorSettings.StartColor = System.Drawing.Color.Blue
        myScheme.EditorSettings.EndColor = System.Drawing.Color.Red
        myScheme.EditorSettings.FieldName = "Maximum"

        Map1.Extents = myLayer.Envelope
        Map1.Layers.Add(myLayer)

        myLayer.ApplyScheme(myScheme)

        'Add labels
        Dim expression As String = "[Maximum]"
        Dim ls As New LabelSymbolizer()
        ls.Orientation = ContentAlignment.MiddleRight
        Map1.AddLabels(myLayer, expression, "", ls)

        Map1.Invalidate()
        Map1.MapFrame.ResetBuffer()

    End Sub

End Class